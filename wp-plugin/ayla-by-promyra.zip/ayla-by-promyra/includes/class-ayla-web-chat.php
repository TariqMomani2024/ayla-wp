<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ayla_Web_Chat {

	const HIDE_META = '_ayla_hide_chat';

	public static function register() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_ayla_web_chat', array( __CLASS__, 'message' ) );
		add_action( 'wp_ajax_nopriv_ayla_web_chat', array( __CLASS__, 'message' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta' ), 10, 2 );
	}

	public static function meta_box() {
		$types = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'] );
		foreach ( $types as $type ) {
			add_meta_box( 'ayla-chat-visibility', 'Ayla', array( __CLASS__, 'render_meta_box' ), $type, 'side', 'low' );
		}
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'ayla_chat_visibility', 'ayla_chat_visibility_nonce' );
		echo '<label><input type="checkbox" name="ayla_hide_chat" value="1"' . checked( '1', get_post_meta( $post->ID, self::HIDE_META, true ), false ) . '> ' . esc_html( Ayla_I18n::t( 'hide_chat' ) ) . '</label>';
		echo '<p class="description">' . esc_html( Ayla_I18n::t( 'hide_chat_help' ) ) . '</p>';
	}

	public static function save_meta( $post_id, $post ) {
		if ( ! isset( $_POST['ayla_chat_visibility_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ayla_chat_visibility_nonce'] ) ), 'ayla_chat_visibility' ) ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		if ( ! empty( $_POST['ayla_hide_chat'] ) ) {
			update_post_meta( $post_id, self::HIDE_META, '1' );
		} else {
			delete_post_meta( $post_id, self::HIDE_META );
		}
	}

	public static function assets() {
		if ( ! Ayla_Settings::is_configured() ) {
			return;
		}

		if ( is_singular() && '1' === get_post_meta( get_queried_object_id(), self::HIDE_META, true ) ) {
			return;
		}

		$style_version  = filemtime( AYLA_PLUGIN_DIR . 'assets/web-chat.css' );
		$script_version = filemtime( AYLA_PLUGIN_DIR . 'assets/web-chat.js' );

		wp_enqueue_style( 'ayla-web-chat', AYLA_PLUGIN_URL . 'assets/web-chat.css', array(), $style_version );
		wp_enqueue_script( 'ayla-web-chat', AYLA_PLUGIN_URL . 'assets/web-chat.js', array(), $script_version, true );
		$lang = self::language();
		$copy = array(
			'ar' => array(
				'title' => 'المساعد الذكي', 'online' => 'متصل الآن', 'messageLabel' => 'كيف يمكنني مساعدتك؟', 'messagePlaceholder' => 'اكتب رسالتك...', 'send' => 'إرسال', 'genericError' => 'تعذر إرسال الرسالة الآن. يرجى المحاولة لاحقاً.', 'whatsapp' => 'التواصل عبر واتساب', 'chatHere' => 'المحادثة هنا', 'chooseTitle' => 'كيف تحب أن نتواصل؟', 'expand' => 'تكبير المحادثة', 'shrink' => 'تصغير المحادثة', 'close' => 'إغلاق المحادثة', 'newChat' => 'محادثة جديدة',
			),
			'en' => array(
				'title' => 'Smart assistant', 'online' => 'Online now', 'messageLabel' => 'How can I help?', 'messagePlaceholder' => 'Write your message...', 'send' => 'Send', 'genericError' => 'Your message could not be sent. Please try again later.', 'whatsapp' => 'Continue on WhatsApp', 'chatHere' => 'Chat here', 'chooseTitle' => 'How would you like to continue?', 'expand' => 'Expand chat', 'shrink' => 'Shrink chat', 'close' => 'Close chat', 'newChat' => 'New conversation',
			),
		);
		wp_localize_script( 'ayla-web-chat', 'AylaWebChat', array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'ayla_web_chat' ),
			'lang'        => $lang,
			'i18n'        => $copy,
			'logoUrl'     => add_query_arg( 'v', (string) filemtime( AYLA_PLUGIN_DIR . 'assets/ayla-logo.png' ), AYLA_PLUGIN_URL . 'assets/ayla-logo.png' ),
			'whatsappUrl' => self::whatsapp_url(),
		) );
	}

	/** The account's WhatsApp link, cached briefly; empty unless the owner has switched WhatsApp on in the Ayla service. */
	private static function whatsapp_url() {
		$cached = get_transient( 'ayla_web_chat_whatsapp' );
		if ( is_string( $cached ) ) {
			return $cached;
		}

		$res = Ayla_Client::relay( 'GET', '/web-chat/config', array(), null, array() );
		$url = $res['ok'] && ! empty( $res['data']['whatsapp_url'] ) ? esc_url_raw( (string) $res['data']['whatsapp_url'] ) : '';
		if ( 0 !== strpos( $url, 'https://wa.me/' ) ) {
			$url = '';
		}

		set_transient( 'ayla_web_chat_whatsapp', $url, $res['ok'] ? 10 * MINUTE_IN_SECONDS : 5 * MINUTE_IN_SECONDS );

		return $url;
	}

	/**
	 * The language the visitor is reading the site in: the multilingual plugin or theme if there is one, else the
	 * site locale. The language of the Ayla account is only a last resort. (The JS also follows <html lang>.)
	 */
	private static function language() {
		$code = '';

		if ( function_exists( 'dentacare_lang' ) ) {
			$code = (string) dentacare_lang();
		} elseif ( function_exists( 'pll_current_language' ) ) {
			$code = (string) pll_current_language( 'slug' );
		} elseif ( defined( 'ICL_LANGUAGE_CODE' ) ) {
			$code = (string) ICL_LANGUAGE_CODE;
		} else {
			$code = (string) determine_locale();
		}

		$code = strtolower( substr( $code, 0, 2 ) );
		if ( in_array( $code, array( 'ar', 'en' ), true ) ) {
			return $code;
		}

		$cached = get_transient( 'ayla_web_chat_language' );
		if ( is_string( $cached ) && in_array( $cached, array( 'ar', 'en' ), true ) ) {
			return $cached;
		}

		$res  = Ayla_Client::request( 'GET', '/account' );
		$lang = $res['ok'] && isset( $res['data']['default_language'] ) ? strtolower( substr( (string) $res['data']['default_language'], 0, 2 ) ) : ( is_rtl() ? 'ar' : 'en' );
		$lang = 'ar' === $lang ? 'ar' : 'en';
		set_transient( 'ayla_web_chat_language', $lang, $res['ok'] ? 6 * HOUR_IN_SECONDS : 5 * MINUTE_IN_SECONDS );

		return $lang;
	}

	public static function message() {
		check_ajax_referer( 'ayla_web_chat', 'nonce' );
		$visitor = isset( $_POST['visitor_id'] ) ? sanitize_text_field( wp_unslash( $_POST['visitor_id'] ) ) : '';
		$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

		if ( ! preg_match( '/^[0-9a-f-]{36}$/i', $visitor ) || '' === $message ) {
			wp_send_json_error( array( 'message' => __( 'يرجى كتابة رسالة صحيحة.', 'ayla-by-promyra' ) ), 422 );
		}

		$conversation = isset( $_POST['conversation_id'] ) ? absint( $_POST['conversation_id'] ) : 0;
		// "New conversation" in the widget: open a fresh one instead of returning to the open one.
		$fresh = ! empty( $_POST['fresh'] ) && ! $conversation;

		if ( ! $conversation ) {
			$conversation = self::start( $visitor, $fresh );
			if ( ! $conversation ) {
				wp_send_json_error( array( 'message' => __( 'تعذر بدء المحادثة الآن.', 'ayla-by-promyra' ) ), 503 );
			}
		}

		// The assistant can take a while (model calls, booking). A shorter wait here would show the visitor an error
		// while the service is still working on the message, and a booking made in the meantime would go unnoticed.
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 70 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- hosts may disable it.
		}

		$send = static function ( $conversation_id ) use ( $visitor, $message ) {
			return Ayla_Client::relay( 'POST', '/web-chat/conversations/' . $conversation_id . '/messages', array(), wp_json_encode( array(
				'visitor_id' => $visitor,
				'message'    => $message,
			) ), array(), 60 );
		};

		$res = $send( $conversation );

		// The visitor's browser remembers a conversation id for weeks. If the service no longer has that
		// conversation (old, or cleaned up), start a new one and carry on instead of failing for ever.
		if ( ! $res['ok'] && 404 === (int) $res['status'] ) {
			$fresh = self::start( $visitor );
			if ( $fresh ) {
				$conversation = $fresh;
				$res          = $send( $conversation );
			}
		}

		if ( ! $res['ok'] ) {
			error_log( 'Ayla web chat message failed: HTTP ' . (int) $res['status'] . ' (' . sanitize_key( (string) $res['error']['code'] ) . ')' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			wp_send_json_error( array( 'message' => __( 'تعذر إرسال الرسالة الآن.', 'ayla-by-promyra' ) ), 503 );
		}

		wp_send_json_success( array_merge( $res['data'], array( 'conversation_id' => $conversation ) ) );
	}

	/** Starts (or finds the open) conversation of this visitor. @return int 0 when the service did not answer */
	private static function start( $visitor, $fresh = false ) {
		$body  = array( 'visitor_id' => $visitor );
		if ( $fresh ) {
			$body['new_conversation'] = true;
		}
		$start = Ayla_Client::relay( 'POST', '/web-chat/start', array(), wp_json_encode( $body ), array() );

		return $start['ok'] && ! empty( $start['data']['conversation_id'] ) ? (int) $start['data']['conversation_id'] : 0;
	}
}